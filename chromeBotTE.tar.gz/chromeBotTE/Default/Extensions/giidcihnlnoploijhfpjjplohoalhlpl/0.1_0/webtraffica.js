document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        alert('test');
		javascript:StartSurf();
		document.getElementsByClassName('button')[1].click();
    }
}
