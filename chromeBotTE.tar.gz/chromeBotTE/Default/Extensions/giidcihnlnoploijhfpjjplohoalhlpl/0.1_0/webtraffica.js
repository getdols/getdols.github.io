document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        StartSurf();
    }
}
