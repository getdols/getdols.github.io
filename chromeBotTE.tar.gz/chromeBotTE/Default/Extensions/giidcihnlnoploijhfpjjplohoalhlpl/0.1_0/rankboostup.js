document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		setTimeout(function() {
			document.getElementById('username').value = 'getdols';
			document.getElementsByClassName('password')[0].value = 'getdols90';
			document.getElementsByClassName('form-signin')[0].submit();
		}, 6000)
	}
}