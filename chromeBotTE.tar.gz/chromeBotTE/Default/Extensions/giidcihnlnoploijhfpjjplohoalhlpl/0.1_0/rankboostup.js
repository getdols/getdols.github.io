document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		$('#username').val('getdols');
		$('.password').val('getdols90');
		//$(".form-signin").submit();
	}
}