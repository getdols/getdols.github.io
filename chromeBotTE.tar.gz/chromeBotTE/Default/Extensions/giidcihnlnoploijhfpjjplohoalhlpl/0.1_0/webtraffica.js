document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		setTimeout(javascript:StartSurf(), 5000)
    }
}
