document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		setTimeout(StartSurf, 5000)
    }
}
