window.addEventListener('load', function(){
	setTimeout(function() {
    	this.window.focus();
		//StartSurf();
		 document.getElementsByClassName('button')[1].click();
	}, 2000)
}, false);
