document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		//setTimeout(function(){ 	javascript:StartSurf(); }, 10000);
	
		setTimeout(function(){ document.getElementsByClassName('button')[1].click(); }, 10000);
    }
}
