document.onreadystatechange = function() {
    if (document.readyState == "complete") {
	setTimeout(function(){ document.getElementsByClassName('button')[1].click(); }, 10000);
    }
}
