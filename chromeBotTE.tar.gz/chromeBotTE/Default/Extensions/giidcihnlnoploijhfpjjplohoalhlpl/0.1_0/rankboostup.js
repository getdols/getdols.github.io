document.onreadystatechange = function() {
    if (document.readyState == "complete") {
		document.getElementById('username').value = 'getdols';
		document.getElementsByClassName('password')[0].value = 'getdols90';
		document.getElementsByClassName('form-signin')[0].submit();
	}
}