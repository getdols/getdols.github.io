document.onreadystatechange = function() {
    if (document.readyState == "complete") {
        javascript:StartSurf();
    }
}
